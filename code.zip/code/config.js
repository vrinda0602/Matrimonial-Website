var mysql = require('mysql2');

module.exports = {
	connection : mysql.createConnection ({
		host : 'localhost',
		database : 'node_matrimony',//'DBMSproject',
		user : 'root', // mysql username
	 	password : 'Googolpds71072~', //mysql password
	})
}
